STUDIO GUIDE 3D ASSET PACKAGE

Included files
- studio-guide.glb: web-ready glTF 2.0 binary with PBR materials, an articulated transform-node rig and four embedded animation clips.
- studio-guide-fallback.png: generated full-body static PNG fallback / poster with transparent background.
- studio-guide-preview.jpg: dark-background preview of the fallback character image.
- StudioGuide.tsx: reusable React + Three.js viewer component with a fallback image, animation selection, viewport pause, background-tab pause, resize handling and reduced-motion support.
- studio-guide-animation-manifest.json: asset metadata and clip names.

Embedded animation clips
1. Idle - Gentle Breathing (3.0 seconds)
2. Wave - Welcome (2.25 seconds)
3. Present - Showcase (2.4 seconds)
4. Think - Reflect (2.2 seconds)

Rig details and limitations
- The GLB uses a hierarchical transform-node rig, not a skinned/deformable humanoid mesh.
- Body parts are separate meshes parented to named pivot nodes. Animation clips target node rotations and translations.
- This works with Three.js GLTFLoader + AnimationMixer. Animation clips are embedded in the GLB.
- It is an original stylised digital-studio guide, not a photoreal scan or a model of Akshit.
- The PNG fallback is separately generated and will not be pixel-identical to the procedural 3D model.
- This is a usable first-pass web character asset, not a production-quality Mixamo/FBX character rig.

React integration
1. Add Three.js to the existing Vite project: npm install three
2. Copy studio-guide.glb and studio-guide-fallback.png into public/assets/3d/.
3. Copy StudioGuide.tsx into src/components/.
4. Import and use:

<StudioGuide animation="Wave - Welcome" className="h-[520px] w-full" />

Suggested animation sequence
- Hero: Wave - Welcome, then Idle - Gentle Breathing
- Services / Selected Work: Present - Showcase
- Process / Insights: Think - Reflect
- Default when no section is active: Idle - Gentle Breathing

Performance notes
- Keep the fallback visible until the GLB loads.
- Lazy-load the GLB when the hero approaches the viewport if delaying the model improves first paint.
- Use the static fallback for reduced-motion, unsupported WebGL, or low-power/mobile devices.
- Keep all website copy, headings and calls to action as real HTML, never as text inside a canvas.
- Do not block the initial page render on the GLB request.

Validation
- GLB header, JSON chunk, binary buffer, nodes, meshes, materials and four animation clips were validated locally.
- The GLB loaded into a local glTF-capable scene parser.
- The React component has not been tested inside the user's deployed React/Vite site. Run the build and browser tests after adding Three.js.
